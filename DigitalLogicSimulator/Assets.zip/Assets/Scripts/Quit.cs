﻿using UnityEngine;

public class Quit : MonoBehaviour
{
    public void endEverything()
    {
        Application.Quit();
    }
}