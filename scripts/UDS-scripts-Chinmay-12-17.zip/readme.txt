use this command to log: 

candump can0,671:7FF > /tmp/chinmay/CANlog.txt